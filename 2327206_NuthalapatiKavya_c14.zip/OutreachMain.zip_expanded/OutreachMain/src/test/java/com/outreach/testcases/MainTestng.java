package com.outreach.testcases;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.outreach.pageObjects.Becognizantpage;
import com.outreach.pageObjects.OnecognizantPage;
import com.outreach.pageObjects.OutreachPage;
import com.outreach.pageObjects.VolunteerPage;
import com.outreach.utilities.DriverSetUp;

public class MainTestng {
	public static WebDriver driver;
	static Becognizantpage becognizant;
	static OnecognizantPage onec;
	static OutreachPage outreach;
	static VolunteerPage vol;
	
	@BeforeClass
	@Parameters({"browser"})
	public void beforeClass(String br) {
		
		driver=DriverSetUp.driverInstantiate(br);
		becognizant=new Becognizantpage(driver);
		onec=new OnecognizantPage(driver) ;
		outreach=new OutreachPage(driver);
		vol=new VolunteerPage(driver);		
	}
	
	@Test(priority=1)
	void validateclickProfile() throws InterruptedException {
		becognizant.clickProfile();
		
	}
	
	@Test(priority=2)
	void validateUserInfo() throws InterruptedException {
		becognizant.captureUserInfo();
	}
	
	@Test(priority=3)
    void clickOne() {
    	onec.clickOneCognizant();
    }
	
	@Test(priority=4)
	void validateclickOutreach() throws InterruptedException {
		onec.clickOutReach();
	}
	
	@Test(priority=5)
	void validateprintMenus() {
		outreach.printMenus();
	}
	
	
	@Test(priority=6)
	void validatePrintSubMenus() {
		outreach.printSubMenus();
	}
	
	
	@Test(priority=7)
	void validatePrintEventDetails() {
		outreach.PrintEventDetails();
	}
	
	
	@Test(priority=8)
	void validateSearchAndPrintEventFilter() throws IOException, InterruptedException {
		outreach.searchAndPrintEventFilter();
	}
	
	
	@Test(priority=9)
	void validateClickMyVolunteering() {
		vol.clickMyVolunteering();
	}
	
	
	@Test(priority=10)
	void validatePrintCards() {
		vol.printCards();
	}
	
	@AfterClass
   void Afterclass() {	
		DriverSetUp.driverTearDown();
	}
}
