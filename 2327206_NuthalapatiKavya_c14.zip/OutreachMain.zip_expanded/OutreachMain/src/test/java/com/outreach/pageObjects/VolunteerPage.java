package com.outreach.pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class VolunteerPage {
	WebDriver driver;
	public VolunteerPage(WebDriver driver) {
		this.driver=driver;
	}
	public void clickMyVolunteering() {
		
  	  driver.findElement(By.linkText("My Volunteering")).click();
    }
	
    public void printCards() {
  	  driver.findElement(By.xpath("//ul[@class='tabs']/li[3]")).click();
		List<WebElement> cards = driver.findElements(By.xpath("//div[@class='profilevoltext']"));
		for(int i=0 ;i<cards.size(); i++)
		{
		     System.out.println(cards.get(i).getText());
		}

    }
}
