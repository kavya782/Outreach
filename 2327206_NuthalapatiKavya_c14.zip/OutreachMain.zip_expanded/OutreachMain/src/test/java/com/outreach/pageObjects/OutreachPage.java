package com.outreach.pageObjects;

import java.io.IOException;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.outreach.utilities.ExcelUtils;

public class OutreachPage {
	WebDriver driver;
	Actions actions;
	String Search = "",location="",EventType="",week="",fromdate="",todate="";
	public OutreachPage(WebDriver driver) {
		this.driver=driver;
	}

    public void printMenus() {
    	
    	driver.switchTo().frame("appFrame");

		List<WebElement> menus = driver.findElements(By.xpath("//ul[@class='navbar-nav paddingleft5']/li/a"));
		for(int i=0 ;i<menus.size(); i++)
		{
		     System.out.println(menus.get(i).getText());
		}

    }
    public void printSubMenus() {
    	actions = new Actions(driver);

		//Events 
		WebElement Events =  driver.findElement(By.xpath("//a[text()='Events']"));
		actions.moveToElement(Events).build().perform();
		WebElement subEvents = driver.findElement(By.xpath("//a[normalize-space()='Upcoming Events']"));
	    System.out.println(subEvents.getText());
 
		
	    //Donate
        WebElement Donate =  driver.findElement(By.xpath("//a[text()='Donate']"));
		actions.moveToElement(Donate).build().perform();
		List<WebElement> subDonate = driver.findElements(By.xpath("//a[text()='Donate']/following::div[1]/a"));
		for(int i=0 ;i<subDonate.size(); i++)
		{
		     System.out.println(subDonate.get(i).getText());
		}

		//Explore
		WebElement Explore =  driver.findElement(By.xpath("//a[normalize-space()='Explore']"));
		actions.moveToElement(Explore).build().perform();
		List<WebElement> subExplore = driver.findElements(By.xpath("//a[normalize-space()='Explore']/following::div[1]/a"));
		for(int i=0 ;i<subExplore.size(); i++)
		{
			 System.out.println(subExplore.get(i).getText());
		}

		//Readmore
		WebElement Readmore =  driver.findElement(By.xpath("//a[normalize-space()='Read More']"));
		actions.moveToElement(Readmore).build().perform();
		List<WebElement> subReadmore = driver.findElements(By.xpath("//a[normalize-space()='Read More']/following::div[1]/a"));
		for(int i=0 ;i<subReadmore.size(); i++)
		{
			 System.out.println(subReadmore.get(i).getText());
		}
	
    }
    
    
      public void PrintEventDetails() {
    	//View All Events click
  		driver.findElement(By.id("viewevents-admin")).click();

  		//Print all events 
  		List<WebElement> eventsName = driver.findElements(By.xpath("//div[@class='col-lg-12 col-md-12 borderbottom']/div"));
  		List<WebElement> eventsDate = driver.findElements(By.xpath("//div[@class='event_date']"));
  		List<WebElement> eventsLocation = driver.findElements(By.xpath("//div[@class='event_address']/span"));

  		for(int i=0 ;i<eventsName.size(); i++)
  		{
  			 System.out.println(eventsName.get(i).getAttribute("title"));
  			 System.out.println(eventsDate.get(i).getText());
  			 System.out.println(eventsLocation.get(i).getAttribute("title"));
  			 System.out.println();
  		}
      }
      
//      public void clickUpcomingEvents() {
//    	  
//    	WebElement Events =  driver.findElement(By.xpath("//a[text()='Events']"));
//  		actions.moveToElement(Events).build().perform();
//  		driver.findElement(By.xpath("//a[normalize-space()='Upcoming Events']")).click();
//  		
//      }
//    
      
      public void searchAndPrintEventFilter() throws IOException, InterruptedException {
		String file=System.getProperty("user.dir")+"\\testData\\mydata.xlsx";
		int rows=ExcelUtils.getRowCount(file, "Sheet1");
		for(int i=1;i<=rows;i++)//
		{
			//read data from excel
			location=ExcelUtils.getCellData(file,"Sheet1",i,1);
			EventType=ExcelUtils.getCellData(file,"Sheet1",i,2);
			week=ExcelUtils.getCellData(file,"Sheet1",i,3);
			fromdate=ExcelUtils.getCellData(file,"Sheet1",i,4);
			todate=ExcelUtils.getCellData(file,"Sheet1",i,5);

		}
		driver.findElement(By.className("vieweventDrop")).click();

		//Locations
		//clicking on the drop down
		driver.findElement(By.xpath("//button[@class='btn dropdown-toggle btn-default btn-light' and @title='Coimbatore']")).click();
		List<WebElement> options = driver.findElements(By.xpath("//span[@class='dropdown-item-inner ']"));
		for(int i=0; i<options.size(); i++)
		{
			String chosing_option = options.get(i).getText();
			if(chosing_option.equalsIgnoreCase(location))
			{
				options.get(i).click();
			}
		}

		//Event Type
		driver.findElement(By.xpath("//button[@class='btn dropdown-toggle bs-placeholder btn-default btn-light']")).click();
		for(int i=0; i<options.size(); i++)
		{
			String chosing_option = options.get(i).getText();
			if(chosing_option.equalsIgnoreCase(EventType))
			{
				options.get(i).click();
			}
		}

		//Weekend/Weekday
        driver.findElement(By.xpath("//button[@class='btn dropdown-toggle btn-default btn-light' and @title = 'Choose']")).click();
		for(int i=0; i<options.size(); i++)
		{
			String chosing_option = options.get(i).getText();
			if(chosing_option.equalsIgnoreCase(week))
			{
				options.get(i).click();
			}
		}

		//Selecting from date
		driver.findElement(By.xpath("//input[@id='fromDate']")).sendKeys(fromdate);

 
		//Selecting to date
		driver.findElement(By.xpath("//input[@id='toDate']")).sendKeys(todate);

		//Thread.sleep(5000);
		//Click on search
		driver.findElement(By.id("Viewallsearch")).click();
		List<WebElement> filterEventsName = driver.findElements(By.xpath("//div[@id='divsearchevents']/div/div[1]/div"));
		List<WebElement> filterEventsDate = driver.findElements(By.xpath("//div[@id='divsearchevents']/div/div[2]/div[2]/div/div[2]"));
		List<WebElement> filterEventsLocation = driver.findElements(By.xpath("//div[@id='divsearchevents']/div/div[2]/div[3]/div[2]/span"));
		for(int i=0 ;i<filterEventsName.size(); i++)
		{
			 System.out.println(filterEventsName.get(i).getText());
			 System.out.println(filterEventsDate.get(i).getText());
			 System.out.println(filterEventsLocation.get(i).getText());
			 System.out.println();
		}
		Thread.sleep(5000);
		
		driver.findElement(By.className("vieweventDrop")).click();
		
		String randomNum = RandomStringUtils.randomNumeric(1);
  		int randomInt = Integer.parseInt(randomNum);
  		JavascriptExecutor js = (JavascriptExecutor)driver;
  		for(int i=0;i<options.size();i++)
  		{
  			if(i==randomInt)
  			{
  				System.out.println("Random city: "+options.get(i).getText());
  				js.executeScript("arguments[0].click();", options.get(i));
   
  			}
  		}
  		Thread.sleep(5000);
        driver.findElement(By.id("Viewallsearch")).click();
		List<WebElement> randomEventsName = driver.findElements(By.xpath("//div[@id='divsearchevents']/div/div[1]/div"));
		List<WebElement> randomEventsDate = driver.findElements(By.xpath("//div[@id='divsearchevents']/div/div[2]/div[2]/div/div[2]"));
		List<WebElement> randomEventsLocation = driver.findElements(By.xpath("//div[@id='divsearchevents']/div/div[2]/div[3]/div[2]/span"));
		for(int i=0 ;i<randomEventsName.size(); i++)
		{
			 System.out.println(randomEventsName.get(i).getText());
			 System.out.println(randomEventsDate.get(i).getText());
			 System.out.println(randomEventsLocation.get(i).getText());
			 System.out.println();
		}

      }


}
