package com.outreach.pageObjects;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Becognizantpage  {
	
	WebDriver driver;
	WebElement profile;
	String name,mail;
	public Becognizantpage(WebDriver driver) {
		this.driver=driver;
	}
	
	public void clickProfile() throws InterruptedException {
		 profile = driver.findElement(By.id("O365_MainLink_Me"));
		 Thread.sleep(10000);
		 profile.click();
	}
	public void captureUserInfo() throws InterruptedException {
		 name =driver.findElement(By.id("mectrl_currentAccount_primary")).getText();
		System.out.println(name);
		Thread.sleep(2000);
 
	 mail=driver.findElement(By.id("mectrl_currentAccount_secondary")).getText();
		System.out.println(mail);
		Thread.sleep(5000);
	}
	public void clickOneCognizant() {
		driver.findElement(By.linkText("OneCognizant")).click();
	}
	public void clickOutReach() throws InterruptedException {
		Set<String> windows = driver.getWindowHandles();
        for (String OneCognizant : windows) 
		{
	            driver.switchTo().window(OneCognizant);
	    }
 
	    WebElement search = driver.findElement(By.id("oneC_searchAutoComplete"));
		search.sendKeys("Outreach");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[@id='newSearchAppsLST']/div/div")).click();
		
	}
	
	

}