package com.outreach.pageObjects;
//import com.outreach.utilities.*;

//import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.interactions.Actions;



public class OnecognizantPage {
	WebDriver driver;
	//String Search = "",location="",EventType="",week="",fromdate="",todate="";
	public OnecognizantPage(WebDriver driver) {
		this.driver=driver;
	}
	public void clickOneCognizant() {
		driver.findElement(By.linkText("OneCognizant")).click();
	}
	public void clickOutReach() throws InterruptedException {
		Set<String> windows = driver.getWindowHandles();
        for (String OneCognizant : windows) 
		{
	            driver.switchTo().window(OneCognizant);
	    }
 
	    WebElement search = driver.findElement(By.id("oneC_searchAutoComplete"));
		search.sendKeys("Outreach");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[@id='newSearchAppsLST']/div/div")).click();
		
	}
	
	
      
      
}
