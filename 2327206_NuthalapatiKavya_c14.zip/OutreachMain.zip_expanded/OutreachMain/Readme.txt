Problem Statement: Outreach

Validate current event displayed in Outreach.
Get event details from Outreach.
Validate all menus and sub-menus from Outreach.
Validate Filter option in Outreach
Validate event based on interest is visible in Outreach.
Validate event details in Outreach.
(Suggested Site: https://be.cognizant.com)

Detailed Description: Main Project

Navigate to Be. Cognizant Website and capture the user information.
Click on One Cognizant Application.
Search Outreach in Search bar and click on Outreach application from search results.
Print all menus and submenus are visible while mouse over cursor.
Print Event details based on interest is visible in Outreach.
Validate Search event filter option based on Location, Event type, Weekend/Weekdays, From date and To date and print the search results.
Repeat Step 6 by selecting Random location.
Click on My Volunteering.
Click on Volunteers around me and Print all the Cards.
Note: Take all necessary screenshots for all the testcases and print all the data in the console.

Key Automation Scope

Handling alert, different browser windows, search option.
Navigating back to home page.
Extract multiple options items & store in collections.
Capture warning message.
Data Driven approach.
Cross Browser Testing.